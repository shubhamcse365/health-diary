import { GoogleGenAI, Type } from "@google/genai";
import { AIResponse, Consultation, MedicalHistory } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const SYSTEM_INSTRUCTION = `You are a medical AI assistant for a telemedicine platform. Your goal is to structure, summarize, and derive clinical insights from consultation notes. 
Always act as an assistive tool, not a diagnostic one. 
Avoid making unsafe medical claims. 
Focus on extracting symptoms, medications, and diagnoses accurately.`;

export async function processConsultation(
  notes: string,
  previousHistory?: MedicalHistory
): Promise<AIResponse> {
  const model = "gemini-3-flash-preview";
  
  const historyContext = previousHistory 
    ? `Previous Medical History Summary: ${previousHistory.cumulativeSummary}\nRecurring Conditions: ${previousHistory.recurringConditions.join(", ")}`
    : "No previous medical history available.";

  const prompt = `
    Consultation Notes:
    ${notes}

    ${historyContext}

    Please analyze the consultation notes and provide:
    1. A concise summary of the visit.
    2. Extracted entities: symptoms, medications (with dosage if mentioned), and diagnosis.
    3. Clinical insights: any patterns, risks, or anomalies based on this visit and previous history.
    4. An updated cumulative medical history summary that incorporates this new information.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          summary: { type: Type.STRING, description: "Concise summary of the visit" },
          entities: {
            type: Type.OBJECT,
            properties: {
              symptoms: { type: Type.ARRAY, items: { type: Type.STRING } },
              medications: { type: Type.ARRAY, items: { type: Type.STRING } },
              diagnosis: { type: Type.ARRAY, items: { type: Type.STRING } },
            },
            required: ["symptoms", "medications", "diagnosis"],
          },
          insights: { type: Type.STRING, description: "Clinical insights and patterns" },
          cumulativeUpdate: { type: Type.STRING, description: "Updated cumulative medical history summary" },
        },
        required: ["summary", "entities", "insights", "cumulativeUpdate"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("AI failed to generate a response.");
  
  return JSON.parse(text) as AIResponse;
}

export async function identifyTrends(consultations: Consultation[]): Promise<any[]> {
  const model = "gemini-3-flash-preview";
  
  const notes = consultations.map(c => `Date: ${c.date}\nNotes: ${c.notes}`).join("\n\n");
  
  const prompt = `
    Analyze the following sequence of medical consultations for a patient and identify any quantifiable trends (e.g., blood pressure, weight, pain levels, or frequency of symptoms).
    Return a list of data points for visualization.
    
    Consultations:
    ${notes}
  `;

  const response = await ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            label: { type: Type.STRING, description: "What is being measured (e.g., 'Weight')" },
            value: { type: Type.NUMBER, description: "The numeric value" },
            date: { type: Type.STRING, description: "The date of measurement" },
          },
          required: ["label", "value", "date"],
        },
      },
    },
  });

  const text = response.text;
  if (!text) return [];
  
  return JSON.parse(text);
}
