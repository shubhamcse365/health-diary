import React from "react";
import { Link, useLocation } from "react-router-dom";
import { Activity, User, LogOut, LayoutDashboard, ClipboardList, Stethoscope } from "lucide-react";
import { cn } from "../lib/utils";
import { auth } from "../firebase";

interface LayoutProps {
  children: React.ReactNode;
  userRole?: "PATIENT" | "DOCTOR";
  onLogout?: () => void;
}

export default function Layout({ children, userRole, onLogout }: LayoutProps) {
  const location = useLocation();
  const currentUser = auth.currentUser;

  const navItems = userRole === "DOCTOR" 
    ? [
        { name: "Dashboard", path: "/doctor", icon: LayoutDashboard },
        { name: "Patients", path: "/doctor/patients", icon: User },
        { name: "Consultations", path: "/doctor/consultations", icon: Stethoscope },
      ]
    : [
        { name: "Dashboard", path: "/patient", icon: LayoutDashboard },
        { name: "My History", path: "/patient/history", icon: ClipboardList },
        { name: "Consultations", path: "/patient/consultations", icon: Stethoscope },
      ];

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Activity className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold text-slate-900 tracking-tight">MediLog</span>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-slate-100 rounded-full">
              <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center overflow-hidden">
                {currentUser?.photoURL ? (
                  <img src={currentUser.photoURL} alt="Profile" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <User className="w-4 h-4 text-blue-600" />
                )}
              </div>
              <span className="text-sm font-medium text-slate-700 hidden sm:inline-block">
                {currentUser?.displayName || "User"}
              </span>
            </div>
            <button 
              onClick={onLogout}
              className="p-2 text-slate-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex flex-col md:flex-row max-w-7xl mx-auto w-full">
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-white md:border-r border-slate-200 p-4 md:sticky md:top-16 md:h-[calc(100vh-4rem)]">
          <nav className="space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-200",
                  location.pathname === item.path
                    ? "bg-blue-50 text-blue-700"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                )}
              >
                <item.icon className={cn("w-5 h-5", location.pathname === item.path ? "text-blue-600" : "text-slate-400")} />
                {item.name}
              </Link>
            ))}
          </nav>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-4 md:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

