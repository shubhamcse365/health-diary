import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Activity, 
  Send, 
  User, 
  Stethoscope, 
  FileText, 
  Pill, 
  AlertCircle,
  Loader2,
  CheckCircle2,
  History,
  ChevronLeft,
  Save
} from "lucide-react";
import { processConsultation } from "../services/geminiService";
import { AIResponse, Consultation, MedicalHistory } from "../types";
import { cn } from "../lib/utils";
import { db, collection, addDoc, doc, setDoc, getDoc, handleFirestoreError, OperationType, auth } from "../firebase";

interface ConsultationRoomProps {
  patientId: string;
  patientName: string;
  onComplete: () => void;
  onBack: () => void;
}

export default function ConsultationRoom({ patientId, patientName, onComplete, onBack }: ConsultationRoomProps) {
  const [notes, setNotes] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [aiResult, setAiResult] = useState<AIResponse | null>(null);

  const handleProcess = async () => {
    if (!notes.trim()) return;
    setIsProcessing(true);
    try {
      // Fetch previous history for context
      const historyDoc = await getDoc(doc(db, "medicalHistories", patientId));
      const previousHistory = historyDoc.exists() ? historyDoc.data() as MedicalHistory : undefined;
      
      const result = await processConsultation(notes, previousHistory);
      setAiResult(result);
    } catch (error) {
      console.error("AI Processing Error:", error);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSave = async () => {
    if (!aiResult || !auth.currentUser) return;
    setIsSaving(true);
    try {
      const consultation: Partial<Consultation> = {
        patientId,
        doctorId: auth.currentUser.uid,
        date: new Date().toISOString(),
        notes,
        summary: aiResult.summary,
        entities: aiResult.entities,
        insights: aiResult.insights,
      };

      // 1. Save Consultation
      await addDoc(collection(db, "consultations"), consultation);

      // 2. Update Medical History
      const historyRef = doc(db, "medicalHistories", patientId);
      const historyDoc = await getDoc(historyRef);
      
      const updatedHistory: MedicalHistory = {
        patientId,
        cumulativeSummary: aiResult.cumulativeUpdate || aiResult.summary,
        recurringConditions: Array.from(new Set([
          ...(historyDoc.exists() ? historyDoc.data().recurringConditions : []),
          ...aiResult.entities.diagnosis
        ])),
        trends: historyDoc.exists() ? historyDoc.data().trends : [],
        lastUpdated: new Date().toISOString(),
      };

      await setDoc(historyRef, updatedHistory);
      
      onComplete();
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, "consultations/medicalHistories");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5 text-slate-500" />
          </button>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-3">
              <Stethoscope className="w-6 h-6 text-blue-600" />
              Consultation with {patientName}
            </h1>
            <p className="text-sm text-slate-500">Patient ID: {patientId} • Status: Active Session</p>
          </div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-700 rounded-full text-xs font-bold uppercase tracking-wider">
          <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
          Live Session
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left: Notes Input */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col h-[600px]">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Consultation Notes
              </h2>
              <span className="text-xs text-slate-400 font-medium italic">AI will structure these notes automatically</span>
            </div>
            
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Start typing symptoms, observations, and prescriptions here..."
              className="flex-1 w-full p-4 border border-slate-100 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-slate-700 leading-relaxed placeholder:text-slate-300"
            />

            <div className="mt-6 flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Activity className="w-4 h-4" />
                Real-time medical entity detection active
              </div>
              <button
                onClick={handleProcess}
                disabled={isProcessing || !notes.trim()}
                className={cn(
                  "flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all shadow-sm",
                  isProcessing || !notes.trim()
                    ? "bg-slate-100 text-slate-400 cursor-not-allowed"
                    : "bg-blue-600 text-white hover:bg-blue-700 hover:shadow-md"
                )}
              >
                {isProcessing ? (
                  <>
                    <Loader2 className="w-5 h-5 animate-spin" />
                    Processing with AI...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5" />
                    Process & Summarize
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right: AI Insights & Summary */}
        <div className="space-y-6">
          <AnimatePresence mode="wait">
            {!aiResult ? (
              <motion.div 
                key="empty"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl h-[600px] flex flex-col items-center justify-center text-center p-8"
              >
                <div className="bg-white p-4 rounded-full shadow-sm mb-4">
                  <Activity className="w-8 h-8 text-blue-400" />
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">AI Insights Pending</h3>
                <p className="text-slate-500 max-w-xs">
                  Enter consultation notes on the left and click "Process" to see AI-generated summaries and clinical insights.
                </p>
              </motion.div>
            ) : (
              <motion.div 
                key="result"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                {/* AI Summary Card */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500" />
                    <h2 className="text-lg font-bold text-slate-900">Visit Summary</h2>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed">
                    {aiResult.summary}
                  </p>
                </div>

                {/* Entities Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-3">
                      <Activity className="w-4 h-4 text-rose-500" />
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Symptoms</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {aiResult.entities.symptoms.map(s => (
                        <span key={s} className="px-2 py-1 bg-rose-50 text-rose-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div className="flex items-center gap-2 mb-3">
                      <Pill className="w-4 h-4 text-emerald-500" />
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider">Medications</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {aiResult.entities.medications.map(m => (
                        <span key={m} className="px-2 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                          {m}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Clinical Insights */}
                <div className="bg-gradient-to-br from-indigo-600 to-blue-700 p-6 rounded-2xl text-white shadow-lg shadow-indigo-200">
                  <div className="flex items-center gap-2 mb-4">
                    <AlertCircle className="w-5 h-5" />
                    <h2 className="text-lg font-bold">Clinical Insights</h2>
                  </div>
                  <p className="text-indigo-50 text-sm leading-relaxed">
                    {aiResult.insights}
                  </p>
                </div>

                {/* Cumulative Update */}
                <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <History className="w-5 h-5 text-amber-500" />
                    <h2 className="text-lg font-bold text-slate-900">Updated History Snapshot</h2>
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed italic">
                    "{aiResult.cumulativeUpdate}"
                  </p>
                </div>

                <button 
                  onClick={handleSave}
                  disabled={isSaving}
                  className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold text-lg hover:bg-slate-800 transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-2"
                >
                  {isSaving ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Finalizing...
                    </>
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      Finalize & Save Consultation
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

