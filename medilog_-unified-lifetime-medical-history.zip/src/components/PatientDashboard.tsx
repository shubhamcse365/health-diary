import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  Activity, 
  Calendar, 
  Clock, 
  FileText, 
  Pill, 
  TrendingUp, 
  AlertCircle,
  ChevronRight,
  Plus,
  Loader2
} from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from "recharts";
import { cn } from "../lib/utils";
import { db, auth, onSnapshot, collection, query, where, doc, handleFirestoreError, OperationType } from "../firebase";
import { Consultation, MedicalHistory } from "../types";

export default function PatientDashboard() {
  const [consultations, setConsultations] = useState<Consultation[]>([]);
  const [history, setHistory] = useState<MedicalHistory | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.currentUser) return;

    const patientId = auth.currentUser.uid;

    // 1. Listen to Medical History
    const historyUnsubscribe = onSnapshot(
      doc(db, "medicalHistories", patientId),
      (doc) => {
        if (doc.exists()) {
          setHistory(doc.data() as MedicalHistory);
        }
      },
      (error) => handleFirestoreError(error, OperationType.GET, `medicalHistories/${patientId}`)
    );

    // 2. Listen to Consultations
    const consultationsQuery = query(
      collection(db, "consultations"),
      where("patientId", "==", patientId)
    );

    const consultationsUnsubscribe = onSnapshot(
      consultationsQuery,
      (snapshot) => {
        const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Consultation));
        setConsultations(docs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        setLoading(false);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "consultations")
    );

    return () => {
      historyUnsubscribe();
      consultationsUnsubscribe();
    };
  }, []);

  if (loading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  const activeMedications = Array.from(new Set(consultations.flatMap(c => c.entities?.medications || [])));

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Welcome back, {auth.currentUser?.displayName?.split(' ')[0]}</h1>
          <p className="text-slate-500">Your health summary is up to date.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-sm hover:shadow-md">
          <Plus className="w-4 h-4" />
          Request Consultation
        </button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Consultations", value: consultations.length.toString(), icon: Activity, color: "text-rose-600", bg: "bg-rose-50" },
          { label: "Condition Status", value: history?.recurringConditions[0] || "Stable", icon: TrendingUp, color: "text-blue-600", bg: "bg-blue-50" },
          { label: "Last Updated", value: history ? new Date(history.lastUpdated).toLocaleDateString() : "N/A", icon: Calendar, color: "text-amber-600", bg: "bg-amber-50" },
          { label: "Active Meds", value: activeMedications.length.toString(), icon: Pill, color: "text-emerald-600", bg: "bg-emerald-50" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4"
          >
            <div className={cn("p-3 rounded-lg", stat.bg)}>
              <stat.icon className={cn("w-6 h-6", stat.color)} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
              <p className="text-lg font-bold text-slate-900">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Longitudinal History Chart */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Health Trends
              </h2>
              <select className="text-sm border-slate-200 rounded-lg focus:ring-blue-500 focus:border-blue-500">
                <option>Blood Pressure</option>
                <option>Heart Rate</option>
                <option>Weight</option>
              </select>
            </div>
            <div className="h-[300px] w-full">
              {history?.trends && history.trends.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={history.trends}>
                    <defs>
                      <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                    <XAxis 
                      dataKey="date" 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 10, fill: '#64748b' }}
                      tickFormatter={(val) => new Date(val).toLocaleDateString()}
                      dy={10}
                    />
                    <YAxis 
                      axisLine={false} 
                      tickLine={false} 
                      tick={{ fontSize: 12, fill: '#64748b' }}
                    />
                    <Tooltip 
                      labelFormatter={(val) => new Date(val).toLocaleDateString()}
                      contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="value" 
                      stroke="#2563eb" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorValue)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="h-full flex items-center justify-center text-slate-400 text-sm italic">
                  No trend data available yet.
                </div>
              )}
            </div>
          </div>

          {/* Recent Consultations */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-600" />
              Consultation History
            </h2>
            <div className="space-y-4">
              {consultations.length > 0 ? consultations.map((consultation) => (
                <div 
                  key={consultation.id}
                  className="group p-4 rounded-xl border border-slate-100 hover:border-blue-200 hover:bg-blue-50/30 transition-all cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-3">
                      <div className="bg-white p-2 rounded-lg border border-slate-200">
                        <Calendar className="w-4 h-4 text-slate-500" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-slate-900">Dr. {consultation.doctorId.substring(0, 5)}...</p>
                        <p className="text-xs text-slate-500">{new Date(consultation.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition-colors" />
                  </div>
                  <p className="text-sm text-slate-600 line-clamp-2 mb-3">
                    {consultation.summary}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {consultation.entities?.medications.map(med => (
                      <span key={med} className="px-2 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-full uppercase tracking-wider">
                        {med}
                      </span>
                    ))}
                  </div>
                </div>
              )) : (
                <p className="text-center text-slate-400 py-8 italic">No consultations found.</p>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar Insights */}
        <div className="space-y-6">
          {/* AI Cumulative Summary */}
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-2xl text-white shadow-lg shadow-blue-200">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5" />
              <h2 className="text-lg font-bold">Health Snapshot</h2>
            </div>
            <p className="text-blue-50 text-sm leading-relaxed mb-6">
              {history?.cumulativeSummary || "Your medical history will be summarized here after your first consultation."}
            </p>
            {history && (
              <div className="space-y-3">
                {history.recurringConditions.map((condition, idx) => (
                  <div key={idx} className="flex items-center gap-2 text-xs font-medium bg-white/10 p-2 rounded-lg">
                    <AlertCircle className="w-4 h-4 text-blue-200" />
                    {condition}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Active Medications */}
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Pill className="w-5 h-5 text-emerald-600" />
              Active Medications
            </h2>
            <div className="space-y-4">
              {activeMedications.length > 0 ? activeMedications.map((med, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="bg-emerald-50 p-2 rounded-lg">
                    <Pill className="w-4 h-4 text-emerald-600" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-slate-900">{med}</p>
                    <p className="text-xs text-slate-500">As prescribed</p>
                  </div>
                </div>
              )) : (
                <p className="text-xs text-slate-400 italic">No active medications listed.</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

