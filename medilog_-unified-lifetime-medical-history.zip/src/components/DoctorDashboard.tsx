import React, { useState, useEffect } from "react";
import { motion } from "motion/react";
import { 
  Users, 
  Search, 
  Calendar, 
  Clock, 
  ChevronRight, 
  Activity, 
  AlertCircle,
  Stethoscope,
  Plus,
  Loader2
} from "lucide-react";
import { cn } from "../lib/utils";
import { db, onSnapshot, collection, query, where, handleFirestoreError, OperationType } from "../firebase";
import { UserProfile } from "../types";

export default function DoctorDashboard() {
  const [patients, setPatients] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    // Listen to all patients
    const patientsQuery = query(
      collection(db, "users"),
      where("role", "==", "PATIENT")
    );

    const unsubscribe = onSnapshot(
      patientsQuery,
      (snapshot) => {
        const docs = snapshot.docs.map(doc => doc.data() as UserProfile);
        setPatients(docs);
        setLoading(false);
      },
      (error) => handleFirestoreError(error, OperationType.LIST, "users")
    );

    return () => unsubscribe();
  }, []);

  const filteredPatients = patients.filter(p => 
    p.displayName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (loading) {
    return (
      <div className="h-[60vh] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Doctor's Dashboard</h1>
          <p className="text-slate-500">You have {patients.length} patients registered in the system.</p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input 
              type="text" 
              placeholder="Search patients..." 
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 py-2 border border-slate-200 rounded-lg text-sm focus:ring-blue-500 focus:border-blue-500 w-64"
            />
          </div>
          <button className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all shadow-sm">
            <Plus className="w-4 h-4" />
            Add Patient
          </button>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Total Patients", value: patients.length.toString(), icon: Users, color: "text-blue-600", bg: "bg-blue-50" },
          { label: "Today's Visits", value: "0", icon: Stethoscope, color: "text-emerald-600", bg: "bg-emerald-50" },
          { label: "Critical Cases", value: "0", icon: AlertCircle, color: "text-rose-600", bg: "bg-rose-50" },
          { label: "Avg. Wait Time", value: "12 min", icon: Clock, color: "text-amber-600", bg: "bg-amber-50" },
        ].map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center gap-4"
          >
            <div className={cn("p-3 rounded-lg", stat.bg)}>
              <stat.icon className={cn("w-6 h-6", stat.color)} />
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">{stat.label}</p>
              <p className="text-lg font-bold text-slate-900">{stat.value}</p>
            </div>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Patient List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <Users className="w-5 h-5 text-blue-600" />
                Active Patients
              </h2>
              <button className="text-sm text-blue-600 font-medium hover:underline">View All</button>
            </div>
            <div className="divide-y divide-slate-100">
              {filteredPatients.length > 0 ? filteredPatients.map((patient) => (
                <div 
                  key={patient.uid}
                  className="p-4 hover:bg-slate-50 transition-colors flex items-center justify-between group cursor-pointer"
                >
                  <div className="flex items-center gap-4">
                    <img 
                      src={patient.photoURL || `https://picsum.photos/seed/${patient.uid}/100/100`} 
                      alt={patient.displayName} 
                      className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <h3 className="text-sm font-bold text-slate-900">{patient.displayName}</h3>
                      <p className="text-xs text-slate-500">{patient.age || '??'}y • {patient.gender || 'N/A'} • {patient.email}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-8">
                    <div className="hidden sm:block text-right">
                      <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">Role</p>
                      <p className="text-sm font-bold text-slate-900">{patient.role}</p>
                    </div>
                    <div className="flex items-center gap-4">
                      <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700">
                        Active
                      </span>
                      <ChevronRight className="w-5 h-5 text-slate-300 group-hover:text-blue-600 transition-colors" />
                    </div>
                  </div>
                </div>
              )) : (
                <p className="text-center text-slate-400 py-8 italic">No patients found.</p>
              )}
            </div>
          </div>
        </div>

        {/* Upcoming Consultations */}
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
            <h2 className="text-lg font-bold text-slate-900 mb-6 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-blue-600" />
              Today's Schedule
            </h2>
            <div className="space-y-6 relative before:absolute before:left-[19px] before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-100">
              <p className="text-center text-slate-400 py-4 italic text-sm">No appointments scheduled for today.</p>
            </div>
            <button className="w-full mt-8 py-3 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all">
              View Full Schedule
            </button>
          </div>

          {/* AI Insights Panel */}
          <div className="bg-gradient-to-br from-emerald-600 to-teal-700 p-6 rounded-2xl text-white shadow-lg shadow-emerald-200">
            <div className="flex items-center gap-2 mb-4">
              <Activity className="w-5 h-5" />
              <h2 className="text-lg font-bold">Clinical Insights</h2>
            </div>
            <div className="space-y-4">
              <div className="bg-white/10 p-3 rounded-xl">
                <p className="text-xs font-bold text-emerald-200 uppercase mb-1">AI Monitoring</p>
                <p className="text-sm leading-relaxed">
                  The system is monitoring patient records for recurring symptoms and medication trends.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

