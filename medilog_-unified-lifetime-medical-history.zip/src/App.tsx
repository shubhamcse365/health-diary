import React, { useState, useEffect, Component } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { UserRole, UserProfile } from "./types";
import Layout from "./components/Layout";
import PatientDashboard from "./components/PatientDashboard";
import DoctorDashboard from "./components/DoctorDashboard";
import ConsultationRoom from "./components/ConsultationRoom";
import { Stethoscope, User, Activity, LogIn, Loader2 } from "lucide-react";
import { cn } from "./lib/utils";
import { auth, googleProvider, signInWithPopup, onAuthStateChanged, signOut, db, doc, getDoc, setDoc } from "./firebase";

// Error Boundary Component
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: any;
}

class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: any) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      let errorMessage = "Something went wrong.";
      try {
        const parsed = JSON.parse(this.state.error.message);
        errorMessage = `Firestore Error: ${parsed.error} during ${parsed.operationType} on ${parsed.path}`;
      } catch (e) {
        errorMessage = this.state.error.message || errorMessage;
      }

      return (
        <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white p-8 rounded-3xl border border-slate-200 shadow-xl text-center space-y-4">
            <div className="inline-flex items-center justify-center p-3 bg-red-100 rounded-2xl mb-4">
              <Activity className="w-8 h-8 text-red-600" />
            </div>
            <h1 className="text-2xl font-bold text-slate-900">Application Error</h1>
            <p className="text-slate-500 text-sm leading-relaxed">{errorMessage}</p>
            <button 
              onClick={() => window.location.reload()}
              className="w-full py-3 bg-slate-900 text-white rounded-xl font-bold hover:bg-slate-800 transition-all"
            >
              Reload Application
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}



export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [roleSelection, setRoleSelection] = useState<UserRole | null>(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
        if (userDoc.exists()) {
          setUser(userDoc.data() as UserProfile);
        } else {
          // User exists in Auth but not in Firestore yet
          // This happens during first-time login
          if (roleSelection) {
            const newProfile: UserProfile = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || "",
              displayName: firebaseUser.displayName || "Anonymous",
              role: roleSelection,
              photoURL: firebaseUser.photoURL || undefined,
            };
            await setDoc(doc(db, "users", firebaseUser.uid), newProfile);
            setUser(newProfile);
          } else {
            // Need to select role first
            setUser(null);
          }
        }
      } else {
        setUser(null);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, [roleSelection]);

  const handleLogin = async (role: UserRole) => {
    setRoleSelection(role);
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (error) {
      console.error("Login Error:", error);
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
    setUser(null);
    setRoleSelection(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-10 h-10 text-blue-600 animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4">
        <div className="max-w-md w-full space-y-8 bg-white p-8 rounded-3xl border border-slate-200 shadow-xl">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center justify-center p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-200 mb-4">
              <Activity className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-slate-900 tracking-tight">MediLog</h1>
            <p className="text-slate-500">Unified Lifetime Medical History</p>
          </div>

          <div className="space-y-4">
            <button
              onClick={() => handleLogin(UserRole.PATIENT)}
              className="w-full flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white rounded-xl border border-slate-200 group-hover:border-blue-200 shadow-sm">
                  <User className="w-6 h-6 text-slate-600 group-hover:text-blue-600" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-900">Patient Portal</p>
                  <p className="text-xs text-slate-500">Login with Google</p>
                </div>
              </div>
              <LogIn className="w-5 h-5 text-slate-400 group-hover:text-blue-600" />
            </button>

            <button
              onClick={() => handleLogin(UserRole.DOCTOR)}
              className="w-full flex items-center justify-between p-4 bg-slate-50 border border-slate-200 rounded-2xl hover:border-blue-500 hover:bg-blue-50 transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="p-3 bg-white rounded-xl border border-slate-200 group-hover:border-blue-200 shadow-sm">
                  <Stethoscope className="w-6 h-6 text-slate-600 group-hover:text-blue-600" />
                </div>
                <div className="text-left">
                  <p className="font-bold text-slate-900">Doctor Portal</p>
                  <p className="text-xs text-slate-500">Login with Google</p>
                </div>
              </div>
              <LogIn className="w-5 h-5 text-slate-400 group-hover:text-blue-600" />
            </button>
          </div>

          <div className="pt-6 border-t border-slate-100 text-center">
            <p className="text-xs text-slate-400 font-medium uppercase tracking-widest">Hackathon Edition v1.0</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <Layout userRole={user.role} onLogout={handleLogout}>
          <Routes>
            {user.role === UserRole.PATIENT ? (
              <>
                <Route path="/patient" element={<PatientDashboard />} />
                <Route path="/patient/history" element={<PatientDashboard />} />
                <Route path="/patient/consultations" element={<PatientDashboard />} />
                <Route path="*" element={<Navigate to="/patient" replace />} />
              </>
            ) : (
              <>
                <Route path="/doctor" element={<DoctorDashboard />} />
                <Route path="/doctor/patients" element={<DoctorDashboard />} />
                <Route path="/doctor/consultations" element={<ConsultationRoom 
                  patientId="p1" 
                  patientName="Shubham Kumar" 
                  onComplete={() => {}} 
                  onBack={() => window.history.back()} 
                />} />
                <Route path="*" element={<Navigate to="/doctor" replace />} />
              </>
            )}
          </Routes>
        </Layout>
      </Router>
    </ErrorBoundary>
  );
}

