export enum UserRole {
  PATIENT = "PATIENT",
  DOCTOR = "DOCTOR",
}

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  photoURL?: string;
  phoneNumber?: string;
  age?: number;
  gender?: string;
  bloodGroup?: string;
}

export interface Consultation {
  id: string;
  patientId: string;
  doctorId: string;
  date: string; // ISO string
  notes: string; // Raw consultation notes
  summary?: string; // AI-generated summary
  entities?: {
    symptoms: string[];
    medications: string[];
    diagnosis: string[];
  };
  insights?: string; // AI-generated insights
}

export interface MedicalHistory {
  patientId: string;
  cumulativeSummary: string;
  recurringConditions: string[];
  trends: {
    label: string;
    value: number;
    date: string;
  }[];
  lastUpdated: string;
}

export interface AIResponse {
  summary: string;
  entities: {
    symptoms: string[];
    medications: string[];
    diagnosis: string[];
  };
  insights: string;
  cumulativeUpdate?: string;
}
